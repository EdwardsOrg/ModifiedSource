/*
 * Copyright (C) 2013 Marek Vasut <marex@denx.de>
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef __ASM_ARCH_SPL_H__
#define __ASM_ARCH_SPL_H__

#define BOOT_DEVICE_NONE	0
#define BOOT_DEVICE_NAND	1

#endif	/* __ASM_ARCH_SPL_H__ */
