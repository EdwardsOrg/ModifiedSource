/*
 * Copyright (C) 2011 Vladimir Zapolskiy <vz@mleia.com>
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef _LPC32XX_SYS_PROTO_H
#define _LPC32XX_SYS_PROTO_H

void lpc32xx_uart_init(unsigned int uart_id);

#endif /* _LPC32XX_SYS_PROTO_H */
